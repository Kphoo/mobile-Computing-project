package com.example.healthadviser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button welcomepage;
    ImageButton logoimage;
    TextView welcome;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        welcomepage = (Button) findViewById(R.id.welcomepage);
//        logoimage=(ImageButton) findViewById(R.id.logoimage);
        welcome=(TextView) findViewById(R.id.welcome);

        welcomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent myIntent = new Intent (MainActivity.this ,Home.class);

                startActivity(myIntent);
            }
        });
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.actionbar, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.setting:
//                Intent myIntent = new Intent(MainActivity.this,Setting.class);
//                startActivity(myIntent);
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }
}

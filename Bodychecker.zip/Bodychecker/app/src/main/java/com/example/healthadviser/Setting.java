package com.example.healthadviser;

import android.app.AppComponentFactory;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class Setting extends AppCompatActivity {
    TextView Pound; TextView Weight_result; TextView height_result;TextView inches;
    EditText Pound_txt; EditText inches_txt;
    Button weight_convertor; Button height_convertor;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);

        Pound_txt = (EditText) findViewById(R.id.Pound_txt);
        inches_txt = (EditText) findViewById(R.id.inches_txt);
        Pound = (TextView) findViewById(R.id.Pound);
        inches = (TextView) findViewById(R.id.inches);
        Weight_result = (TextView) findViewById(R.id.Weight_result);
        height_result = (TextView) findViewById(R.id.height_result);
        weight_convertor = (Button) findViewById(R.id.weight_convertor);
        height_convertor = (Button) findViewById(R.id.height_convertor);

    }

    public void Convert_Weight(View v){
        double pound=Double.valueOf(Pound_txt.getText().toString());
        double kg=0.453592*pound;
        Weight_result.setText(String.valueOf(kg));
        Weight_result.setText("Your weight into kg " +kg);

        Toast.makeText(getApplicationContext(),"Convert",Toast.LENGTH_LONG).show();
    }
    public void Convert(View v){
        DecimalFormat df2 = new DecimalFormat(".##");
        double inches=Double.valueOf(inches_txt.getText().toString());
        double meter=inches/39.37;
        height_result.setText(String.valueOf(meter));
        height_result.setText("Your height into meter " +df2.format(meter));

        Toast.makeText(getApplicationContext(),"Convert",Toast.LENGTH_LONG).show();
    }
    public  void clear(View v){
        Pound_txt.setText("");
        inches_txt.setText("");
        Pound_txt.requestFocus();
        inches_txt.requestFocus();
//        Toast.makeText(getApplicationContext(),"Clear",Toast.LENGTH_LONG).show();
    }
}

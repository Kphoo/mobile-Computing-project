package com.example.healthadviser;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Overweight extends AppCompatActivity {
    TextView overweight_sugg;
    Button goback1;
//    ImageView overweight;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.overweight);

        goback1 = (Button) findViewById(R.id.goback1);
//        overweight = (ImageView) findViewById(R.id.overweight);
        overweight_sugg = (TextView) findViewById(R.id.overweight_sugg);

        goback1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Overweight.this, Home.class);
                startActivity(myIntent);
            }
        });
    }
}
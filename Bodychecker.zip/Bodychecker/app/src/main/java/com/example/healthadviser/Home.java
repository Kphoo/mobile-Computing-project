package com.example.healthadviser;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class Home extends AppCompatActivity {
    TextView weight, height, overweighttitle, underweighttitle, normaltitle;
    EditText weightinput, heightinput;
    Dialog epicDialog, epicDialog2, epicDialog3;

    Button bmi, btnoverweight, btnunderweight, btnnormal;
    TextView bmi_result, result_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        epicDialog = new Dialog(this);
        Button button = (Button) findViewById(R.id.bmi);
        btnoverweight = (Button) findViewById(R.id.btnoverweight);
        btnunderweight = (Button) findViewById(R.id.btnunderweight);
        btnnormal = (Button) findViewById(R.id.btnnormal);

        overweighttitle = (TextView) findViewById(R.id.overweighttitle);
        underweighttitle = (TextView) findViewById(R.id.underweighttitle);
        normaltitle = (TextView) findViewById(R.id.normaltitle);

        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                bmi = (Button) findViewById(R.id.bmi);
                weight = (TextView) findViewById(R.id.weight);
                weightinput = (EditText) findViewById(R.id.weightinput);
                height = (TextView) findViewById(R.id.height);
                heightinput = (EditText) findViewById(R.id.heightinput);
                bmi_result = (TextView) findViewById(R.id.bmi_result);
                result_text = (TextView) findViewById(R.id.result_text);


                String heightValue = heightinput.getText().toString();

                String weightValue = weightinput.getText().toString();

                DecimalFormat df2 = new DecimalFormat(".##");

                try {
                    final double height = Double.parseDouble(heightValue);

                    double weight = Double.parseDouble(weightValue);
                    double bmi = weight / (height * height);

                    if (weightValue.matches("") || height == 0.0 || height < 0.0 || heightValue.matches("") || weight == 0.0 || weight < 0.0) {
                        Toast.makeText(getApplicationContext(), "Invalid input !", Toast.LENGTH_LONG).show();
                        result_text.setText("");
                        bmi_result.setText("");
                    } else if (bmi >= 18.5 && bmi <= 25) {
                        bmi_result.setText("BMI Value: " + df2.format(bmi));
                        result_text.setText("Normal");
                        AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                        builder.setView(R.layout.dialog_normal);

                        epicDialog = builder.create();
                        epicDialog.show();
                        Button newB = epicDialog.findViewById(R.id.btnnormal);
                        newB.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                weightinput.setText("");
                                heightinput.setText("");
                                epicDialog.dismiss();
                            }
                        });

                    } else if (bmi < 18.5 && bmi > 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                        builder.setView(R.layout.dialog_underweight);

                        epicDialog2 = builder.create();
                        epicDialog2.show();
                        Button newB = epicDialog2.findViewById(R.id.btnunderweight);
                        newB.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                weightinput.setText("");
                                heightinput.setText("");
                                epicDialog2.dismiss();
                                Intent myintent = new Intent(Home.this, Underweight.class);
                                startActivity(myintent);
                            }
                        });

                        bmi_result.setText("BMI Value: " + df2.format(bmi));
                        result_text.setText("Underweight");
                    } else if (bmi > 25) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                        builder.setView(R.layout.dialog_overweight);
                        epicDialog3 = builder.create();
                        epicDialog3.show();
                        Button newB = epicDialog3.findViewById(R.id.btnoverweight);
                        newB.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                weightinput.setText("");
                                heightinput.setText("");
                                epicDialog3.dismiss();
                                Intent myintent = new Intent(Home.this, Overweight.class);
                                startActivity(myintent);
                            }
                        });
                        bmi_result.setText("BMI Value: " + df2.format(bmi));
                        result_text.setText("Overweight");
                    }
                } catch (NumberFormatException ex) {
                    Toast.makeText(getApplicationContext(), "Invalid input !", Toast.LENGTH_LONG).show();
                }




            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.actionbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.setting:
                Intent myIntent = new Intent(Home.this, Setting.class);
                startActivity(myIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}






package com.maths_game.maths.braingames.Activity;

import android.animation.AnimatorInflater;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.maths_game.maths.braingames.R;
//import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity {
    LinearLayout btn_start, btn_rate, btn_setting, btn_feedback;
//    TextView logo,instru;
//    RelativeLayout btn_start, btn_rate, btn_setting, btn_feedback;
//    Button btn_start, btn_rate, btn_setting, btn_feedback;
public static Boolean sound = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        final TextView logo= (TextView) findViewById(R.id.logo);
        final TextView instru= (TextView) findViewById(R.id.instru);
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(10f, 400f);
        valueAnimator.setRepeatCount(5);
        valueAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        valueAnimator.setDuration(4000);
//        MobileAds.initialize(MainActivity.this,getResources().getString(R.string.app_id));
        init();
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float progress=(float) animation.getAnimatedFraction();
                logo.setRotation(progress);
            }

        });
        AnimatorInflater.loadAnimator(
                this, R.animator.valueanimator);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float animatedValue = (float) animation.getAnimatedValue();
                logo.setRotationX(animatedValue);
            }
        });
        valueAnimator.start();

        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StartActivity.class);
                startActivity(intent);
            }
        });

        btn_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Setting_Activity.class);
                startActivity(intent);
            }
        });

        btn_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String appPackageName = getPackageName();
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }
            }
        });

        btn_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendFeedBack();
            }
        });

    }

    private void init() {

        btn_start = (LinearLayout) findViewById(R.id.lv_start);
        btn_feedback = (LinearLayout) findViewById(R.id.lv_feedback);
        btn_rate = (LinearLayout) findViewById(R.id.lv_rate);
        btn_setting = (LinearLayout) findViewById(R.id.lv_setting);

    }


    public void sendFeedBack() {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse(getResources().getString(R.string.mail) +
                    "?subject=" + Uri.encode(getPackageName())));
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MainActivity.this.finishAffinity();
    }
}

package com.maths_game.maths.braingames.Activity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.speech.tts.TextToSpeech;

import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.maths_game.maths.braingames.R;
import com.maths_game.maths.braingames.Utils.Constants;
import com.maths_game.maths.braingames.Utils.DatabaseAccess;
import com.maths_game.maths.braingames.Utils.Model;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;

public class StartActivity extends AppCompatActivity implements TextToSpeech.OnInitListener, Animation.AnimationListener {

    @SuppressLint("StaticFieldLeak")
    public static TextView txt_timer, txt_score, txt_option_1,
            txt_option_2, txt_option_3, txt_option_4, txt_question, txt_test;
    @SuppressLint("StaticFieldLeak")
    public static FrameLayout frame_option1, frame_option2, frame_option3, frame_option4;
    public static TextToSpeech speech;
    public static ArrayList<Integer> total_ques = new ArrayList<>();
    public static ArrayList<Integer> true_ques = new ArrayList<>();
    public static ArrayList<Integer> wrong_ques = new ArrayList<>();
    public static int total_count = 0, true_count = 0, false_count = 0;
    int manTag, opt1, opt2, opt3, op4, n1, n2, ans;
    Random answer = new Random();
    CountDownTimer countDownTimer;
    ImageView img_test;
    String operation, table_name, sign;
    String add, sub, multi, div, hard, easy, medium, mixed;
    Boolean isSound = true;
    String type;
    int score;
    int trueQue, wrongQue = 0;
    boolean isTime = false;
    long continueTime;
    boolean isAnswer = false;
    String true_sond, wron_sound, game_over;
//    MediaPlayer mediaPlayer;
//    AdView addview;
    List<Integer> randomArray = new ArrayList<>();
    boolean isExe_time = false, isScore = false;
    Animation animBlink;
    boolean isAnim = false;
    DatabaseAccess databaseAccess;
    List<Model> modelList;
    int pos = -1;
    String speakString;

    public static void desableView(boolean checked) {

        frame_option1.setEnabled(checked);
        frame_option2.setEnabled(checked);
        frame_option3.setEnabled(checked);
        frame_option4.setEnabled(checked);
        txt_option_1.setEnabled(checked);
        txt_option_2.setEnabled(checked);
        txt_option_3.setEnabled(checked);
        txt_option_4.setEnabled(checked);

    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_new);
        init();
        getData(table_name, type);
        Log.e("modelList+", "" + modelList.size());


        setRandomData();
        setTimer();
//        showbanner();
        startContinueTimer(continueTime);


        frame_option1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {

                isAnim = true;

                frame_option1.startAnimation(animBlink);
                frame_option2.clearAnimation();
                frame_option3.clearAnimation();
                frame_option4.clearAnimation();
                total_count = total_count + 1;
                total_ques.add(total_count);

                String op1 = txt_option_1.getText().toString();
                if (op1.equals(String.valueOf(ans))) {
                    updateIcon1();
                } else {
                    updateIcon();
                }

                desableView(false);
                setTimer();

            }
        });

        frame_option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAnim = true;
                frame_option2.startAnimation(animBlink);
                frame_option1.clearAnimation();
                frame_option3.clearAnimation();
                frame_option4.clearAnimation();

                total_count = total_count + 1;
                total_ques.add(total_count);
                String op1 = txt_option_2.getText().toString();
                if (op1.equals(String.valueOf(ans))) {
                    updateIcon1();
                } else {
                    updateIcon();
                }

                desableView(false);
                setTimer();
            }
        });

        frame_option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAnim = true;
                frame_option3.startAnimation(animBlink);
                frame_option2.clearAnimation();
                frame_option1.clearAnimation();
                frame_option4.clearAnimation();

                total_count = total_count + 1;
                total_ques.add(total_count);
                String op1 = txt_option_3.getText().toString();
                if (op1.equals(String.valueOf(ans))) {
                    updateIcon1();
                } else {
                    updateIcon();
                }
                desableView(false);
                setTimer();
            }
        });

        frame_option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frame_option4.startAnimation(animBlink);
                frame_option1.clearAnimation();
                frame_option3.clearAnimation();
                frame_option2.clearAnimation();
                isAnim = true;

                total_count = total_count + 1;
                total_ques.add(total_count);
                String op1 = txt_option_4.getText().toString();
                if (op1.equals(String.valueOf(ans))) {
                    updateIcon1();
                } else {
                    updateIcon();
                }
                desableView(false);
                setTimer();

            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isExe_time) {

            countDownTimer.cancel();


            startContinueTimer(continueTime);
        }
    }

//    private void showbanner() {
//
//        addview = findViewById(R.id.adView);
//
//        AdRequest adRequest = new AdRequest.Builder().build();
//        addview.loadAd(adRequest);
//    }

    @SuppressLint("SetTextI18n")
    private void init() {

        modelList = new ArrayList<>();
        total_ques.clear();
        true_ques.clear();
//        mediaPlayer = new MediaPlayer();
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        operation = pref.getString(Constants.OPERATION_TYPE, null);
        type = pref.getString(Constants.TYPE, null);
        continueTime = pref.getLong(Constants.SECOND_TIME, 0);
        SharedPreferences pref1 = getSharedPreferences(Constants.MYPREF1, MODE_PRIVATE);
        isSound = pref1.getBoolean(Constants.SOUND, true);
        add = getResources().getString(R.string.addition);
        sub = getResources().getString(R.string.subtraction);
        multi = getResources().getString(R.string.multiplication);
        div = getResources().getString(R.string.division);
        easy = getResources().getString(R.string.easy);
        hard = getResources().getString(R.string.hard);
        medium = getResources().getString(R.string.medium);
        mixed = getResources().getString(R.string.mixed);


        animBlink = AnimationUtils.loadAnimation(this,
                R.anim.blink);

        // set animation listener
        animBlink.setAnimationListener(this);


        if (operation == null) {
            operation = add;

        }
        if (continueTime == 0) {
            continueTime = 20;
        }
        if (type == null) {
            type = easy;
        }
        if (operation.equals(add)) {
            table_name = getResources().getString(R.string.tbl_addition);
        } else if (operation.equals(sub)) {
            table_name = getResources().getString(R.string.tbl_subtraction);
        } else if (operation.equals(multi)) {
            table_name = getResources().getString(R.string.tbl_multi);
        } else if (operation.equals(div)) {
            table_name = getResources().getString(R.string.tbl_division);
        } else if (operation.equals(mixed)) {
            table_name = getResources().getString(R.string.tbl_mixed);
        }
        Log.e("operation===", "" + operation);
        Log.e("isSound===", "" + isSound);
        Log.e("type===", "" + type);

        speech = new TextToSpeech(getApplicationContext(), this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        txt_test = findViewById(R.id.txt_test);
        txt_question = findViewById(R.id.txt_question);
        txt_timer = findViewById(R.id.txt_time);
        txt_score = findViewById(R.id.txt_score);
        txt_option_1 = findViewById(R.id.txt_option_1);
        txt_option_2 = findViewById(R.id.txt_option_2);
        txt_option_3 = findViewById(R.id.txt_option_3);
        txt_option_4 = findViewById(R.id.txt_option_4);
        frame_option1 = findViewById(R.id.frame_option_1);
        frame_option2 = findViewById(R.id.frame_option_2);
        frame_option3 = findViewById(R.id.frame_option_3);
        frame_option4 = findViewById(R.id.frame_option_4);
        img_test = findViewById(R.id.img_test);
        txt_score.setText("" + true_ques.size() + " / " + total_ques.size());
    }

    @SuppressLint("SetTextI18n")
    public void setRandomData() {

        randomArray.clear();

        manTag = answer.nextInt(4) + 1;


        if (pos < modelList.size() - 1) {
            pos = pos + 1;


        } else {
//            countDownTimer.cancel();
            if (!isScore) {
                isScore = true;

                if (score > 35) {
                    speakString = "Pass";
                } else {
                    speakString = "Fail";

                }
                if (MainActivity.sound) {
                    speak(speakString);
                }

                Intent intent = new Intent(StartActivity.this, Score_Activity.class);
                intent.putExtra(Constants.SCORE, score);
                intent.putExtra(Constants.TYPE, type);
                intent.putExtra(Constants.TRUEQUESTION, true_ques.size());
                intent.putExtra(Constants.WRONGQUESTION, wrong_ques.size());
                intent.putExtra(Constants.TITLE, speakString);
                startActivity(intent);
            }
            isExe_time = false;
        }


        sign = modelList.get(pos).getSign();

        n1 = Integer.parseInt(modelList.get(pos).getNumber1());
        n2 = Integer.parseInt(modelList.get(pos).getNumber2());
        txt_question.setText(String.valueOf(n1) + " " + sign + " " + String.valueOf(n2) + " = ");
        ans = Integer.parseInt(modelList.get(pos).getAnswer());

        opt1 = Integer.parseInt(modelList.get(pos).getOp1());
        opt2 = Integer.parseInt(modelList.get(pos).getOp2());
        opt3 = Integer.parseInt(modelList.get(pos).getOp3());
        op4 = Integer.parseInt(modelList.get(pos).getOp4());

        if (manTag == 1) {

            txt_option_1.setText(String.valueOf(op4));
            txt_option_2.setText(String.valueOf(opt1));
            txt_option_3.setText(String.valueOf(opt2));
            txt_option_4.setText(String.valueOf(opt3));


        } else if (manTag == 2) {

            txt_option_2.setText(String.valueOf(op4));
            txt_option_3.setText(String.valueOf(opt1));
            txt_option_1.setText(String.valueOf(opt2));
            txt_option_4.setText(String.valueOf(opt3));


        } else if (manTag == 3) {


            txt_option_3.setText(String.valueOf(op4));
            txt_option_2.setText(String.valueOf(opt1));
            txt_option_1.setText(String.valueOf(opt2));
            txt_option_4.setText(String.valueOf(opt3));


        } else if (manTag == 4) {

            txt_option_4.setText(String.valueOf(op4));
            txt_option_2.setText(String.valueOf(opt1));
            txt_option_3.setText(String.valueOf(opt2));
            txt_option_1.setText(String.valueOf(opt3));


        }


    }

    public void getData(String tablName, String type) {
        databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        modelList = databaseAccess.getRandomData(tablName, type);
        databaseAccess.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        countDownTimer.cancel();
//        mediaPlayer.stop();
    }

    @Override
    protected void onStop() {
        super.onStop();
        countDownTimer.cancel();
//        mediaPlayer.stop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        countDownTimer.cancel();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        countDownTimer.cancel();
//        mediaPlayer.stop();
        Intent intent = new Intent(StartActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void updateIcon() {
//        playVideo(wron_sound);
        isAnswer = false;
        img_test.setVisibility(View.VISIBLE);
        txt_test.setVisibility(View.VISIBLE);
        img_test.setImageResource(R.drawable.ic_worng);
        txt_test.setText(getResources().getString(R.string.wrong));
        speak("Wrong");
//        speak(txt_test.getText().toString());
        Log.e("txt===", "" + txt_test.getText().toString());
        score = score - 10;
        wrongQue += 1;
        txt_score.setText("" + score);

    }

    public void updateIcon1() {
//        playVideo(true_sond);
        isAnswer = true;
        img_test.setVisibility(View.VISIBLE);
        txt_test.setVisibility(View.VISIBLE);
        img_test.setImageResource(R.drawable.ic_correct);
        txt_test.setText(getResources().getString(R.string.correct));
        speak("Correct");
//        speak(txt_test.getText().toString());
        Log.e("txt===", "" + txt_test.getText().toString());
        score = score + 10;
        true_count = true_count + 1;
        true_ques.add(true_count);
        txt_score.setText("" + true_ques.size() + " / " + total_ques.size());
        trueQue += 1;
        txt_score.setText("" + score);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {

            int result = speech.setLanguage(Locale.ENGLISH);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("SPEECH==", "Language is not supported");
            } else {
                String string = txt_test.getText().toString();
                speak(string);
            }
        }
    }

    public void speak(String text) {
        if (isSound) {
            speech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    public void setTimer() {


        if (isAnim) {
            final Handler handler = new Handler();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int timeToBlink = 500;    //in milissegunds
                    try {
                        Thread.sleep(timeToBlink);
                    } catch (Exception e) {
                    }
                    handler.post(new Runnable() {
                        @Override
                        public void run() {

                            txt_score.setText("" + true_ques.size() + " / " + total_ques.size());
                            setRandomData();
                            desableView(true);
                            isTime = false;

                            frame_option1.clearAnimation();
                            frame_option2.clearAnimation();
                            frame_option3.clearAnimation();
                            frame_option4.clearAnimation();
                        }
                    });
                }
            }).start();


        }
    }


    public void startContinueTimer(long continueTime1) {

        isExe_time = true;
        continueTime1 = continueTime1 + 1;
        continueTime1 = continueTime1 * 1000;
        countDownTimer = new CountDownTimer(continueTime1, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                String second = "" + millisUntilFinished / 1000 + " s";
                txt_timer.setText(second);

                continueTime = millisUntilFinished / 1000;
                long time_sec = millisUntilFinished/1000;
                int sec = (int) time_sec;

                if(sec <= 10 && sec>=5){
                    txt_option_1.setVisibility(View.INVISIBLE);
                    txt_option_2.setVisibility(View.INVISIBLE);
                    txt_option_3.setVisibility(View.INVISIBLE);
                    txt_option_4.setVisibility(View.INVISIBLE);
                }else{
                    txt_option_1.setVisibility(View.VISIBLE);
                    txt_option_2.setVisibility(View.VISIBLE);
                    txt_option_3.setVisibility(View.VISIBLE);
                    txt_option_4.setVisibility(View.VISIBLE);
                }


            }

            @Override
            public void onFinish() {
//                playVideo(game_over);
                speak("Game Over");
                Intent intent = new Intent(StartActivity.this, Score_Activity.class);
                intent.putExtra(Constants.SCORE, score);
                intent.putExtra(Constants.TRUEQUESTION, trueQue);
                intent.putExtra(Constants.WRONGQUESTION,wrongQue);
                intent.putExtra(Constants.TYPE, type);
                startActivity(intent);
                isExe_time = false;
            }
        }.start();
    }


    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

        if (animBlink != null) {
            animBlink.cancel();
        }
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

//    public void playVideo(String audioPath) {
//        try {
//            mediaPlayer.reset();
//            AssetFileDescriptor descriptor = getApplicationContext().getAssets().openFd(audioPath);
//            mediaPlayer.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
//            descriptor.close();
//            mediaPlayer.prepare();
//            mediaPlayer.setScreenOnWhilePlaying(true);
//            mediaPlayer.start();
//        } catch (Exception e) {
//        }
//    }

}

package com.maths_game.maths.braingames.Activity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.maths_game.maths.braingames.R;
import com.maths_game.maths.braingames.Utils.Constants;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class Score_Activity extends AppCompatActivity {

    TextView txt_scores, txt_best_score, txt_mode,txt_true_ques, txt_wrong_ques,txt_title;
    Button btn_restart, btn_exit;
    ImageView img_share;
    int score, myscore,wrong_ques, true_ques;;
    String type,title;
    boolean isScore = false;
    LinearLayout lv_score;
    RelativeLayout rl_header;


    boolean interstitialCanceled1;
    InterstitialAd mInterstitialAd;
//    private com.facebook.ads.InterstitialAd facebook_interstitialAd1;
    ConnectionDetector cd;
    int Mainposition = 0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        init();
        type = getIntent().getStringExtra(Constants.TYPE);
        score = getIntent().getIntExtra(Constants.SCORE, 0);
        Log.d("Score ", Integer.toString(score));
        wrong_ques = getIntent().getIntExtra(Constants.WRONGQUESTION, 0);
        true_ques = getIntent().getIntExtra(Constants.TRUEQUESTION, 0);
        title = getIntent().getStringExtra(Constants.TITLE);
        txt_title.setText(title);

        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        myscore = pref.getInt(Constants.SCORE, 0);


        if (myscore == 0) {
            storeScore(score);
            lv_score.setVisibility(View.GONE);
            isScore = true;
            rl_header.setVisibility(View.GONE);

        } else if (myscore < score) {
            storeScore(score);
        }

        SharedPreferences pref1 = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        myscore = pref1.getInt(Constants.SCORE, 0);
        if (isScore == false) {
            lv_score.setVisibility(View.VISIBLE);
            txt_best_score.setText("" + myscore);

            if(myscore > score){

                rl_header.setVisibility(View.GONE);
            }else {
                rl_header.setVisibility(View.VISIBLE);
            }

        }

        Log.e("myscore======", "" + myscore);

        txt_scores.setText("" + score);
        txt_mode.setText(type);
        txt_wrong_ques.setText("" + wrong_ques);
        txt_true_ques.setText("" + true_ques);


        btn_restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitialCanceled1) {
                } else {
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    } else {
                        ContinueIntent1();
                    }
                }

            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Score_Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        img_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sharingIntent1 = new Intent(Intent.ACTION_SEND);
                sharingIntent1.setType("text/plain");
                sharingIntent1.putExtra(Intent.EXTRA_SUBJECT, "Your Scores");
                sharingIntent1.putExtra(Intent.EXTRA_TEXT, "I just scored " + score + " in #maths practice - Can you beat me?" + "\n\n" +"https://play.google.com/store/apps/details?id="+ getPackageName() + System.getProperty("line.separator"));
                startActivity(Intent.createChooser(sharingIntent1, "Share via"));
            }
        });
    }


    @Override
    protected void onStop() {
        super.onStop();

    }

    private void init() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Score_Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        txt_scores = (TextView) findViewById(R.id.txt_scores);
        txt_best_score = (TextView) findViewById(R.id.txt_best_score);
        txt_mode = (TextView) findViewById(R.id.txt_mode);
        img_share = (ImageView) findViewById(R.id.img_share);
        btn_restart = (Button) findViewById(R.id.btn_restart);
        btn_exit = (Button) findViewById(R.id.btn_exit);
        lv_score = (LinearLayout) findViewById(R.id.lv_score);
        rl_header = (RelativeLayout) findViewById(R.id.header);
        txt_title = findViewById(R.id.txt_title);
        txt_true_ques = findViewById(R.id.txt_true_ques);
        txt_wrong_ques = findViewById(R.id.txt_wrong_ques);
//        r_blank = (RelativeLayout) findViewById(R.id.r_blank);



    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Score_Activity.this, MainActivity.class);
        startActivity(intent);
    }

    public void storeScore(int score) {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();
        edit.putInt(Constants.SCORE, score);
        edit.commit();
        edit.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        interstitialCanceled1 = false;
        if (getResources().getString(R.string.ADS_VISIBILITY).equals("YES")) {
            CallNewInsertial1();
        } else {
        }
    }
    @Override
    public void onPause() {
        mInterstitialAd = null;
        interstitialCanceled1 = true;
        super.onPause();
    }



    private void ContinueIntent1() {
        Intent intent = new Intent(Score_Activity.this, StartActivity.class);
        startActivity(intent);
    }

    private void CallNewInsertial1() {
        cd = new ConnectionDetector(Score_Activity.this);

        if (!cd.isConnectingToInternet()) {
           /* alert.showAlertDialog(Home.this, "Internet Connection Error",
                    "Please connect to working Internet connection", false);*/
            return;
        } else {
            mInterstitialAd = new InterstitialAd(Score_Activity.this);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobFullScreenAdsID));
            requestNewInterstitial1();
            mInterstitialAd.setAdListener(new AdListener() {
                public void onAdClosed() {

                    ContinueIntent1();
                }
            });
        }
    }

    private void requestNewInterstitial1() {
        AdRequest adRequest = new AdRequest.Builder().build();
        mInterstitialAd.loadAd(adRequest);
    }
}

package com.maths_game.maths.braingames.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.maths_game.maths.braingames.R;
import com.maths_game.maths.braingames.Utils.Constants;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class Setting_Activity extends AppCompatActivity {

    String add, sub, multi, div, hard, easy, medium, mixed;
    ImageView img_sound;
    //    boolean isSound = true;
    String radio_text;
    RadioButton radio_easy, radio_hard, radio_medium, radio_add, radio_sub, radio_multi, radio_div, radio_mixed;
    Spinner spinner;
    Button btn_dialog;
    String istype;
    long confirmSecond;
    AdView addview;
    InterstitialAd mInterstitialAd;
    boolean interstitialCanceled1;

    ConnectionDetector cd;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.final_setting);
        init();
        //showbanner();

        radio_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrence(add);
            }
        });

        radio_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrence(sub);
            }
        });
        radio_multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrence(multi);
            }
        });
        radio_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrence(div);
            }
        });
        radio_mixed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrence(mixed);
            }
        });

        img_sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.sound) {
                    img_sound.setImageResource(R.drawable.ic_volume_off_black_24dp);
                    MainActivity.sound = false;
                } else if (!MainActivity.sound) {
                    img_sound.setImageResource(R.drawable.ic_volume_up_black_24dp);
                    MainActivity.sound = true;
                }

            }
        });
        radio_easy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSharedPrefrenceradio(easy);
            }
        });

        radio_medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setSharedPrefrenceradio(medium);
            }
        });
        radio_hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setSharedPrefrenceradio(hard);
            }
        });

        btn_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });

    }

    private void init() {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF1, MODE_PRIVATE);
//        isSound = pref.getBoolean(Constants.SOUND, true);
        SharedPreferences pre = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        istype = pre.getString(Constants.OPERATION_TYPE, null);
        confirmSecond = pre.getLong(Constants.SECOND_TIME, 0);
        radio_text = pre.getString(Constants.TYPE, null);

        Log.e("operation_type", "" + istype);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        img_sound = findViewById(R.id.img_sound);
        radio_add = findViewById(R.id.radio_add);
        radio_sub = findViewById(R.id.radio_sub);
        radio_multi = findViewById(R.id.radio_multi);
        radio_div = findViewById(R.id.radio_div);
        radio_mixed = findViewById(R.id.radio_mixed);
        radio_easy = findViewById(R.id.radio_easy);
        radio_medium = findViewById(R.id.radio_medium);
        radio_hard = findViewById(R.id.hard);
        spinner = findViewById(R.id.spinner);
        btn_dialog = findViewById(R.id.btn_dialog);

        add = getResources().getString(R.string.addition);
        sub = getResources().getString(R.string.subtraction);
        multi = getResources().getString(R.string.multiplication);
        div = getResources().getString(R.string.division);
        easy = getResources().getString(R.string.easy);
        hard = getResources().getString(R.string.hard);
        medium = getResources().getString(R.string.medium);
        mixed = getResources().getString(R.string.mixed);
        if (MainActivity.sound) {
            img_sound.setImageResource(R.drawable.ic_volume_up_black_24dp);
//            img_sound = true;
        } else {
            img_sound.setImageResource(R.drawable.ic_volume_off_black_24dp);
        }

        if (radio_text == null || radio_text.isEmpty()) {
            radio_easy.setChecked(true);
        } else if (radio_text.equals(easy)) {
            radio_easy.setChecked(true);
        } else if (radio_text.equals(medium)) {
            radio_medium.setChecked(true);
        } else if (radio_text.equals(hard)) {
            radio_hard.setChecked(true);
        }
        if (istype == null || istype.isEmpty() || istype.equals(add)) {
            radio_add.setChecked(true);
        } else if (istype.equals(sub)) {
            radio_sub.setChecked(true);
        } else if (istype.equals(multi)) {
            radio_multi.setChecked(true);
        } else if (istype.equals(div)) {
            radio_div.setChecked(true);
        } else if (istype.equals(mixed)) {
            radio_mixed.setChecked(true);
        }

        final ArrayAdapter<CharSequence> foodadapter2 = ArrayAdapter.createFromResource(
                this, R.array.time_array, R.layout.spinner_layout);
        foodadapter2.setDropDownViewResource(R.layout.spinner_layout);
        spinner.setAdapter(foodadapter2);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedText = null;
                if (position == 0) {
                    selectedText = add;
                } else if (position == 1) {
                    selectedText = sub;
                } else if (position == 2) {
                    selectedText = multi;
                } else if (position == 3) {
                    selectedText = div;
                }
                setSharedPrefrence(selectedText);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    private void showbanner() {

        addview = findViewById(R.id.adView);

        AdRequest adRequest = new AdRequest.Builder().build();
        addview.loadAd(adRequest);
    }

    public void setSharedPrefrence(String string) {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString(Constants.OPERATION_TYPE, string);
        edit.commit();
        edit.apply();
    }

    public void setSharedPrefrenceboolean(boolean isSound) {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF1, MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();
        edit.putBoolean(Constants.SOUND, isSound);
        edit.commit();
        edit.apply();
    }

    public void setSharedPrefrenceradio(String isSound) {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString(Constants.TYPE, isSound);
        edit.commit();
        edit.apply();
    }


    public void passIntent() {
        Intent intent = new Intent(Setting_Activity.this, StartActivity.class);
        startActivity(intent);
    }


    public void openDialog() {

        final Dialog dialog = new Dialog(Setting_Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.time_dialog);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(lp);

        RadioButton radio_easy, radio_hard, radio_medium;
        final int sec = 10, sec1 = 20, sec2 = 30;
        String second = getResources().getString(R.string.second);

        radio_easy = dialog.findViewById(R.id.radio_easy);
        radio_medium = dialog.findViewById(R.id.radio_medium);
        radio_hard = dialog.findViewById(R.id.hard);
        Button yes = dialog.findViewById(R.id.yes);
        Button no = dialog.findViewById(R.id.no);
        final EditText editText = dialog.findViewById(R.id.edt_path);

        radio_easy.setText("" + sec + " " + second);
        radio_medium.setText("" + sec1 + " " + second);
        radio_hard.setText("" + sec2 + " " + second);

        if (confirmSecond == 10) {
            radio_easy.setChecked(true);
        } else if (confirmSecond == 20 || confirmSecond == 0) {
            radio_medium.setChecked(true);
        } else if (confirmSecond == 30) {
            radio_hard.setChecked(true);
        } else {
            editText.setText("" + confirmSecond);
        }


        radio_easy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmSecond = sec;
                setSharedPrefrenceTime(confirmSecond);
            }
        });
        radio_medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmSecond = sec1;
                setSharedPrefrenceTime(confirmSecond);

            }
        });

        radio_hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmSecond = sec2;
                setSharedPrefrenceTime(confirmSecond);
            }
        });

        if (!TextUtils.isEmpty(editText.getText().toString())) {
            confirmSecond = Long.parseLong(editText.getText().toString());
            setSharedPrefrenceTime(confirmSecond);
        }

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {

                if (!TextUtils.isEmpty(editText.getText().toString())) {
                    confirmSecond = Long.parseLong(editText.getText().toString());
                }
            }
        });
////
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setSharedPrefrenceTime(confirmSecond);

//                   if(!TextUtils.isEmpty(editText.getText().toString())){
//                       confirmSecond = Long.parseLong(editText.getText().toString());
//                   }?
//                setSharedPrefrenceTime(confirmSecond);
                if (interstitialCanceled1) {
                } else {
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    } else {
                        passIntent();
                    }
                }
                dialog.dismiss();


            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitialCanceled1) {
                } else {
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    } else {
                        dialog.dismiss();
                    }
                }
                dialog.dismiss();
                // passIntent();
            }
        });


        dialog.show();
    }


    public void setSharedPrefrenceTime(long isSound) {
        SharedPreferences pref = getSharedPreferences(Constants.MYPREF, MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();
        edit.putLong(Constants.SECOND_TIME, isSound);
        edit.commit();
        edit.apply();
    }


//    @Override
//    protected void onResume() {
//        super.onResume();
//        interstitialCanceled1 = false;
//        if (getResources().getString(R.string.ADS_VISIBILITY).equals("YES")) {
//            CallNewInsertial1();
//        } else {
//        }
//    }
//
//    @Override
//    public void onPause() {
//        mInterstitialAd = null;
//        interstitialCanceled1 = true;
//        super.onPause();
//    }

//    private void CallNewInsertial1() {
//        cd = new ConnectionDetector(Setting_Activity.this);
//
//        if (!cd.isConnectingToInternet()) {
//           /* alert.showAlertDialog(Home.this, "Internet Connection Error",
//                    "Please connect to working Internet connection", false);*/
//            return;
//        } else {
//            mInterstitialAd = new InterstitialAd(Setting_Activity.this);
//            mInterstitialAd.setAdUnitId(getString(R.string.AdmobFullScreenAdsID));
//            requestNewInterstitial1();
//            mInterstitialAd.setAdListener(new AdListener() {
//                public void onAdClosed() {
//                    passIntent();
//                }
//            });
//        }
//    }

    private void requestNewInterstitial1() {
        AdRequest adRequest = new AdRequest.Builder().build();
        mInterstitialAd.loadAd(adRequest);
    }
}
